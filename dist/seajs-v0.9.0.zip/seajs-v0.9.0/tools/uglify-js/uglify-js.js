exports.parser = require("./lib/parse-js");
exports.uglify = require("./lib/process");
